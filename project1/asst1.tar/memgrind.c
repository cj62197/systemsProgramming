//contains the main testing of malloc and free functions
#include "mymalloc.h"
int main()
{
  int z;

  for(z =0; z<150; z++)
  {
    char* x = malloc(sizeof(char));
    free(x);
  }

}
